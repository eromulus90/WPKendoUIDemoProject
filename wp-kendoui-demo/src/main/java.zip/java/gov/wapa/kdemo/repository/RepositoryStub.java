package gov.wapa.kdemo.repository;

public interface RepositoryStub {
	

}
