package gov.wapa.kdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class KendoController {

	/**
	 * the home page for kendo ui
	 * @return
	 */
	@RequestMapping("/kendo")
	public String index() {
		
		return "kendo-ui/index";
	}
}
