package gov.wapa.core.util;

/**
 * general utility to help with string manipulation, type conversion, etc..
 * 
 * @author romulus
 *
 */
public class GeneralUtilities {


}
